-- task 2
SELECT 
c.name AS Category_Name,
f.title AS Film_Title,
f.description AS Film_Description,
f.release_year AS Release_Year
FROM film f
JOIN film_category fc ON f.film_id = fc.film_id
JOIN category c ON fc.category_id = c.category_id
WHERE c.name = 'Documentary'
AND f.description LIKE '%Drama%';

-- task 3

SELECT 
f.title AS Film_Title,
CONCAT(a.last_name, ', ', a.first_name) AS Actor_Name
FROM film f
JOIN film_actor fa ON f.film_id = fa.film_id
JOIN actor a ON fa.actor_id = a.actor_id
WHERE a.first_name = 'JULIA' AND a.last_name = 'MCQUEEN';

-- task 4
SELECT 
f.title AS Film_Title,
CONCAT(a.last_name, ', ', a.first_name) AS Actor_Name
FROM film f
JOIN film_actor fa ON f.film_id = fa.film_id
JOIN actor a ON fa.actor_id = a.actor_id
WHERE f.title = 'AMADEUS HOLY';

-- task 5
SELECT *
FROM customer c
JOIN rental r ON c.customer_id = r.customer_id
JOIN inventory i ON r.inventory_id = i.inventory_id
JOIN film f ON i.film_id = f.film_id
WHERE c.first_name = 'KATHLEEN' AND c.last_name = 'ADAMS';

-- step 6

-- What is the average number of rentals per customer?
-- Which store has the highest number of rentals?
-- Which customer has the highest amount of rentals?
